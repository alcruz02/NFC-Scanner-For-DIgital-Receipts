package com.example.online;

import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.File;
import java.io.IOException;

public class FileContentActivity extends AppCompatActivity {

    private TextView textView; // To show extracted text
    private ZoomableImageView pdfImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_content);

        pdfImageView = findViewById(R.id.pdfImageView);
        textView = findViewById(R.id.textView);

        String filePath = getIntent().getStringExtra("filePath");

        if (filePath != null) {
            File pdfFile = new File(filePath);
            if (pdfFile.exists()) {
                try {
                    displayPdf(pdfFile, pdfImageView);
                } catch (IOException e) {
                    Toast.makeText(this, "Failed to open PDF", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(this, "PDF file not found", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No file path provided", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayPdf(File file, ZoomableImageView imageView) throws IOException {
        ParcelFileDescriptor parcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
        PdfRenderer pdfRenderer = new PdfRenderer(parcelFileDescriptor);
        PdfRenderer.Page page = pdfRenderer.openPage(0); // Open the first page

        Bitmap bitmap = Bitmap.createBitmap(page.getWidth(), page.getHeight(), Bitmap.Config.ARGB_8888);
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);

        imageView.setImageBitmap(bitmap); // Display PDF as image

        performOCR(bitmap); // Extract text from the image

        page.close();
        pdfRenderer.close();
        parcelFileDescriptor.close();
    }

    private void performOCR(Bitmap bitmap) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        InputImage image = InputImage.fromBitmap(bitmap, 0);

        recognizer.process(image)
                .addOnSuccessListener(visionText -> {
                    if (!visionText.getText().isEmpty()) {
                        textView.setText(visionText.getText()); // Display OCR in textview but in the background which cant be seen
                    } else {
                        textView.setText("No text found");
                    }
                })
                .addOnFailureListener(e -> {
                    textView.setText("OCR failed: " + e.getMessage());
                });
    }
}

