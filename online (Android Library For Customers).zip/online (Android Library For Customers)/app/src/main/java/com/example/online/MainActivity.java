package com.example.online;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    private NfcAdapter nfcAdapter;
    private EditText nfcTextbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nfcTextbox = findViewById(R.id.nfc_textbox);
        Button clearButton = findViewById(R.id.clear_button);
        Button openLinkButton = findViewById(R.id.open_link_button);

        // Initialize NFC adapter
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC is not supported on this device.", Toast.LENGTH_SHORT).show();
            finish();
        }

        // Clear the text box
        clearButton.setOnClickListener(view -> nfcTextbox.setText(""));

        // Open link in browser
        openLinkButton.setOnClickListener(view -> {
            String url = nfcTextbox.getText().toString().trim();
            if (!url.isEmpty() && (url.startsWith("http://") || url.startsWith("https://"))) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(browserIntent);
            } else {
                Toast.makeText(this, "No valid URL to open.", Toast.LENGTH_SHORT).show();
            }
        });

        // open receipts button to show pdf list
        Button openReceiptsButton = findViewById(R.id.open_receipts_button);
        openReceiptsButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ReceiptsActivity.class);
            startActivity(intent);
        });



    }

    @Override
    protected void onResume() {
        super.onResume();
        enableNfcForegroundDispatch();
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        disableNfcForegroundDispatch();
    }

    private void enableNfcForegroundDispatch() {
        Intent intent = new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
        IntentFilter[] filters = new IntentFilter[]{
                new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED)
        };
        String[][] techList = new String[][]{};
        nfcAdapter.enableForegroundDispatch(this, pendingIntent, filters, techList);
    }

    private void disableNfcForegroundDispatch() {
        if (nfcAdapter != null) {
            nfcAdapter.disableForegroundDispatch(this);
        }
    }

    private void handleIntent(Intent intent) {
        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(intent.getAction())) {
            processNfcTag(intent);
        }
    }

    private void processNfcTag(Intent intent) {
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        if (tag == null) {
            nfcTextbox.setText("No NFC tag detected.");
            return;
        }

        Ndef ndef = Ndef.get(tag);
        if (ndef == null) {
            nfcTextbox.setText("Not an NDEF tag.");
            return;
        }

        try {
            NdefMessage ndefMessage = ndef.getCachedNdefMessage();
            if (ndefMessage != null) {
                for (NdefRecord record : ndefMessage.getRecords()) {
                    if (record.getTnf() == NdefRecord.TNF_WELL_KNOWN
                            && record.getType()[0] == 0x55) { // 'U' type for URLs
                        String url = parseUrl(record);
                        nfcTextbox.setText(url);
                        return;
                    }
                }
            }
            nfcTextbox.setText("No URL found on this tag.");
        } catch (Exception e) {
            e.printStackTrace();
            nfcTextbox.setText("Error reading NFC tag.");
        }
    }

    private String parseUrl(NdefRecord record) {
        byte[] payload = record.getPayload();
        String prefix = getUrlPrefix(payload[0]);
        String url = new String(payload, 1, payload.length - 1, StandardCharsets.UTF_8);
        return prefix + url;
    }

    private String getUrlPrefix(byte code) {
        switch (code) {
            case 0x01:
                return "http://www.";
            case 0x02:
                return "https://www.";
            case 0x03:
                return "http://";
            case 0x04:
                return "https://";
            default:
                return "";
        }
    }


}
