package com.example.online;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.canvas.parser.PdfTextExtractor;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReceiptsActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSION_READ_STORAGE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipts);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {

            if (Environment.isExternalStorageManager()) {
                loadReceipts();
            } else {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(android.net.Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_PERMISSION_READ_STORAGE);
            }
        } else {

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION_READ_STORAGE);
            } else {
                loadReceipts();
            }
        }
    }

    private void loadReceipts() {
        ListView listView = findViewById(R.id.receipts_list);

        File downloadsFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (downloadsFolder.exists() && downloadsFolder.isDirectory()) {
            List<String> receiptFiles = new ArrayList<>();
            File[] files = downloadsFolder.listFiles();

            if (files != null) {
                for (File file : files) {
                    if (file.isFile() && file.getName().matches("^R\\d+\\.pdf$")) {
                        // Extract the total from the PDF
                        String totalAmount = extractTotalFromPDF(file);
                        // Add filename with extracted total
                        receiptFiles.add(file.getName() + " -           Total:" + totalAmount);
                    }
                }
            }

            // Sort filenames least to greatest
            receiptFiles.sort((file1, file2) -> {
                // Extract only beginning filename before " - Total"
                String file1Name = file1.split(" - ")[0];
                String file2Name = file2.split(" - ")[0];

                int num1 = Integer.parseInt(file1Name.replaceAll("[^0-9]", ""));
                int num2 = Integer.parseInt(file2Name.replaceAll("[^0-9]", ""));

                return Integer.compare(num1, num2);
            });


            // click filename and total to lead to content
            if (!receiptFiles.isEmpty()) {
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, receiptFiles);
                listView.setAdapter(adapter);

                listView.setOnItemClickListener((parent, view, position, id) -> {
                    String selectedItem = receiptFiles.get(position);
                    String selectedFileName = selectedItem.split(" - ")[0]; // Extract just the filename
                    File selectedFile = new File(downloadsFolder, selectedFileName);

                    Intent intent = new Intent(ReceiptsActivity.this, FileContentActivity.class);
                    intent.putExtra("filePath", selectedFile.getAbsolutePath());
                    startActivity(intent);
                });
            } else {
                Toast.makeText(this, "No valid receipt files found in Downloads.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Downloads folder not found.", Toast.LENGTH_SHORT).show();
        }
    }


    private String extractTotalFromPDF(File pdfFile) {
        try {
            PdfReader reader = new PdfReader(pdfFile.getAbsolutePath());
            PdfDocument pdfDoc = new PdfDocument(reader);


            StringBuilder extractedText = new StringBuilder();

            for (int i = 1; i <= pdfDoc.getNumberOfPages(); i++) {
                extractedText.append(PdfTextExtractor.getTextFromPage(pdfDoc.getPage(i))).append("\n");
            }

            pdfDoc.close();
            reader.close();

            // Extract the total amount from the text
            return findTotalAmount(extractedText.toString());

        } catch (Exception e) {
            e.printStackTrace();
            return "Total not found";
        }
    }

    private String findTotalAmount(String text) {
        // Regex to match "Total", "TOTAL", or "Sample Total" but disregard "Subtotal"
        Pattern pattern = Pattern.compile("(?i)(?<!sub)\\b(?:Sample Total|Total)[:]?\\s*(?:\\(₱\\)|₱|\\$)?\\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\\.[0-9]{2})?)\\b");
        Matcher matcher = pattern.matcher(text);

        if (matcher.find()) {
            return matcher.group(1); // Extract the amount
        } else {
            return "Total not found";
        }
    }




    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION_READ_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                loadReceipts();
            } else {
                // Permission denied
                Toast.makeText(this, "Permission to access storage denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PERMISSION_READ_STORAGE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    loadReceipts();
                } else {
                    Toast.makeText(this, "Permission to manage external storage denied.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}
