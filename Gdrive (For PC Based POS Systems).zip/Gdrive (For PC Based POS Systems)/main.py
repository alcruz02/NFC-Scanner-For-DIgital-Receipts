import time
import requests
import os
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import serial
import serial.tools.list_ports
import threading
from tkinterdnd2 import TkinterDnD, DND_FILES
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google.oauth2 import service_account

# Google Drive API Setup
SCOPES = ['https://www.googleapis.com/auth/drive']
SERVICE_ACCOUNT_FILE = 'service_account.json'
PARENT_FOLDER_ID = "14sKmbwmQk_55PGdhmNggUNnLgN5jdKie"


def authenticate():
    creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    return creds


def make_file_public(service, file_id):
    """make file accessible to anyone with link."""
    permission = {
        'type': 'anyone',
        'role': 'reader'
    }
    service.permissions().create(fileId=file_id, body=permission).execute()


def shorten_url(long_url):
    """Shorten URL using TinyURL."""
    try:
        response = requests.get(f"http://tinyurl.com/api-create.php?url={long_url}")
        if response.status_code == 200:
            short_url = response.text.strip()
            print(f"DEBUG: TinyURL Shortened Link: {short_url}")
            return short_url
        else:
            print("ERROR: Failed to shorten URL.")
            return long_url
    except Exception as e:
        print(f"ERROR: TinyURL request failed: {e}")
        return long_url


def upload_pdf(file_path):
    """Upload PDF to Google Drive and return short link."""
    try:
        creds = authenticate()
        service = build('drive', 'v3', credentials=creds)

        file_name = os.path.basename(file_path)
        file_metadata = {'name': file_name, 'parents': [PARENT_FOLDER_ID]}
        media = MediaFileUpload(file_path, mimetype='application/pdf')

        print(f"DEBUG: Uploading file {file_name}...")

        file = service.files().create(body=file_metadata, media_body=media, fields="id").execute()
        file_id = file.get("id")

        if file_id:
            print(f"DEBUG: File uploaded! File ID: {file_id}")
            time.sleep(2)

            make_file_public(service, file_id)
            long_link = f"https://drive.google.com/uc?id={file_id}"
            short_link = shorten_url(long_link)  # Get short link

            print(f"DEBUG: Final Shortened Link: {short_link}")
            return short_link
        else:
            print("ERROR: Failed to retrieve file ID.")
            return None
    except Exception as e:
        print(f"ERROR: Upload error: {e}")
        return None


class ReceiptApp:
    def __init__(self, root):
        self.root = root
        self.root.title("PDF Drag-and-Drop and Serial Sender")
        self.root.geometry("650x850")

        # Drag-and-Drop Area
        self.drop_area = tk.Label(root, text="Drag and Drop PDF Files Here", bg="lightgrey", height=5, width=50)
        self.drop_area.pack(pady=10)
        self.drop_area.drop_target_register(DND_FILES)
        self.drop_area.dnd_bind('<<Drop>>', self.drop)

        # Label to Display Selected File Name
        self.file_label = tk.Label(root, text="No file selected", fg="blue")
        self.file_label.pack(pady=5)

        # Save Receipt Button
        self.save_button = tk.Button(root, text="Save Receipt", command=self.save_receipt, state="disabled")
        self.save_button.pack(pady=10)

        # Serial Monitor Section
        tk.Label(root, text="Serial Monitor").pack(pady=5)
        self.serial_monitor = scrolledtext.ScrolledText(root, height=10, width=70, state='disabled')
        self.serial_monitor.pack(pady=5)

        # Serial Connection Options
        self.com_ports = self.list_com_ports()
        self.com_ports = self.com_ports if self.com_ports else ["No Ports Available"]
        self.com_port = tk.StringVar()
        self.com_port.set(self.com_ports[0])

        tk.Label(root, text="COM Port:").pack()
        tk.OptionMenu(root, self.com_port, *self.com_ports).pack()

        tk.Label(root, text="Baud Rate:").pack()
        self.baud_rate = tk.Entry(root, width=10)
        self.baud_rate.pack()
        self.baud_rate.insert(0, "115200")

        # Connect/Disconnect Buttons
        tk.Button(root, text="Connect Serial", command=self.connect_serial).pack(pady=5)
        tk.Button(root, text="Disconnect Serial", command=self.disconnect_serial).pack(pady=5)

        # Setup Button
        self.setup_button = tk.Button(root, text="Setup Watch Folder", command=self.setup_watch_folder)
        self.setup_button.pack(pady=10)

        # Serial Connection Object
        self.serial_connection = None
        self.selected_file_path = None

    def list_com_ports(self):
        ports = serial.tools.list_ports.comports()
        return [port.device for port in ports]

    def drop(self, event):
        file_path = event.data.strip()
        if os.path.isfile(file_path) and file_path.endswith(".pdf"):
            self.process_pdf(file_path)
        else:
            self.file_label.config(text="Invalid file. Please drop a valid PDF.")

    def process_pdf(self, file_path):
        self.selected_file_path = file_path
        self.save_button.config(state="normal")
        self.file_label.config(text=f"Selected file: {os.path.basename(file_path)}")

    def save_receipt(self):
        if not self.selected_file_path:
            messagebox.showwarning("Warning", "No PDF file selected.")
            return

        start_time = time.time()  # Start timer

        # Upload to Google Drive and retrieve link
        upload_link = upload_pdf(self.selected_file_path)

        end_time = time.time()  # End timer
        elapsed_time = end_time - start_time  # elapsed time

        messagebox.showinfo("Upload Time", f"Upload completed in {elapsed_time:.2f} seconds.")

        # Send link to Arduino
        if upload_link:
            self.send_link_to_serial(upload_link)

    def send_link_to_serial(self, upload_link):
        if not self.serial_connection or not self.serial_connection.is_open:
            messagebox.showerror("Error", "No active serial connection. Please connect first.")
            return

        try:
            message = f"{upload_link}\n"
            self.serial_connection.write(message.encode('utf-8'))
            messagebox.showinfo("Success", f"Link sent to Arduino: {upload_link}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to send link: {e}")

    def connect_serial(self):
        if self.serial_connection and self.serial_connection.is_open:
            messagebox.showwarning("Warning", "Serial connection is already open.")
            return

        try:
            self.serial_connection = serial.Serial(
                port=self.com_port.get(),
                baudrate=int(self.baud_rate.get()),
                timeout=1
            )
            messagebox.showinfo("Success", f"Connected to {self.serial_connection.portstr}")


            self.serial_reader_thread = threading.Thread(target=self.read_serial_data)
            self.serial_reader_thread.daemon = True
            self.serial_reader_thread.start()

        except serial.SerialException as e:
            messagebox.showerror("Error", f"Failed to connect to {self.com_port.get()}: {e}")

    def disconnect_serial(self):
        if self.serial_connection and self.serial_connection.is_open:
            self.serial_connection.close()
            messagebox.showinfo("Disconnected", "Serial connection closed.")
        else:
            messagebox.showwarning("Warning", "No serial connection to close.")

    def read_serial_data(self):
        while True:
            if self.serial_connection and self.serial_connection.is_open:
                try:
                    if self.serial_connection.in_waiting > 0:
                        data = self.serial_connection.read(self.serial_connection.in_waiting)
                        data_str = data.decode('utf-8', errors='ignore')
                        self.update_serial_monitor(data_str)
                except Exception as e:
                    self.update_serial_monitor(f"Error reading serial data: {e}")

    def update_serial_monitor(self, data_str):
        self.serial_monitor.config(state='normal')
        self.serial_monitor.insert(tk.END, data_str)
        self.serial_monitor.yview(tk.END)
        self.serial_monitor.config(state='disabled')

    def monitor_folder(self, folder=None):

        class PDFHandler(FileSystemEventHandler):
            def __init__(self, app):
                self.app = app

            def on_created(self, event):
                if event.src_path.endswith(".pdf"):
                    print(f"DEBUG: Detected new PDF: {event.src_path}")

                    time.sleep(2)

                    try:
                        if os.path.exists(event.src_path):
                            self.app.process_pdf(event.src_path)
                    except Exception as e:
                        messagebox.showerror("Error", f"Failed to process file: {e}")

        event_handler = PDFHandler(self)
        observer = Observer()
        observer.schedule(event_handler, folder, recursive=False)
        observer.start()

        # observer stops when program exits
        self.root.protocol("WM_DELETE_WINDOW", lambda: self.stop_observer(observer))

    def setup_watch_folder(self):
        folder = filedialog.askdirectory(title="Select Folder to Monitor")
        if folder:
            self.monitor_folder(folder)

    def stop_observer(self, observer):
        observer.stop()
        observer.join()
        self.root.destroy()


if __name__ == "__main__":
    root = TkinterDnD.Tk()
    app = ReceiptApp(root)
    root.mainloop()

