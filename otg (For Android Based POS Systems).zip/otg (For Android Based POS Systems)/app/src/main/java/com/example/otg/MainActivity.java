package com.example.otg;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.GeneralSecurityException;
import java.util.List;

import com.google.api.services.drive.DriveScopes;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.FileContent;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.drive.Drive;

import java.util.Collections;



public class MainActivity extends AppCompatActivity {

    private static final int PICK_PDF_REQUEST = 1;
    private static final int BAUD_RATE = 115200; // Fixed baud rate
    private Uri pdfUri;
    private TextView pdfLink, serialMonitor;
    private TextView pdfName; // TextView to display selected PDF name
    private UsbSerialPort usbSerialPort;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // PDF buttons and text box
        Button choosePdf = findViewById(R.id.choosePdf);
        Button uploadPdf = findViewById(R.id.uploadPdf);
        pdfLink = findViewById(R.id.pdfLink);
        pdfName = findViewById(R.id.pdfName); // Initialize the TextView

        // Arduino buttons
        Button connectArduino = findViewById(R.id.connectArduino);
        Button disconnectArduino = findViewById(R.id.disconnectArduino);
        Button sendToArduino = findViewById(R.id.sendToArduino);
        serialMonitor = findViewById(R.id.serialMonitor);

        choosePdf.setOnClickListener(v -> pickPdf());
        uploadPdf.setOnClickListener(v -> {
            if (pdfUri != null) {
                new UploadTask().execute(pdfUri);
            } else {
                Toast.makeText(this, "Please choose a PDF first", Toast.LENGTH_SHORT).show();
            }
        });

        connectArduino.setOnClickListener(v -> connectToArduino());
        disconnectArduino.setOnClickListener(v -> disconnectFromArduino());
        sendToArduino.setOnClickListener(v -> sendLinkToArduino());
    }

    private void pickPdf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("application/pdf");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_PDF_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PDF_REQUEST && resultCode == RESULT_OK && data != null) {
            pdfUri = data.getData();

            // Update the TextView with PDF name
            String fileName = getFileNameFromUri(pdfUri);
            pdfName.setText(fileName);

            Toast.makeText(this, "PDF Selected: " + fileName, Toast.LENGTH_SHORT).show();
        }
    }

    private String getFileNameFromUri(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (nameIndex != -1) {
                        result = cursor.getString(nameIndex);
                    }
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }
        return result;
    }

    private Drive initializeDriveService(Context context) throws GeneralSecurityException, IOException {
        HttpTransport transport = new NetHttpTransport();
        JsonFactory jsonFactory = JacksonFactory.getDefaultInstance();

        // Load service account JSON from assets
        InputStream credentialsStream = context.getAssets().open("service_account.json");

        GoogleCredential credential = GoogleCredential.fromStream(credentialsStream)
                .createScoped(Collections.singleton(DriveScopes.DRIVE_FILE));

        return new Drive.Builder(transport, jsonFactory, credential)
                .setApplicationName("OTG")
                .build();
    }


    private class UploadTask extends AsyncTask<Uri, Void, String> {
        @Override
        protected String doInBackground(Uri... uris) {
            try {
                Drive driveService = initializeDriveService(MainActivity.this);
                Uri pdfUri = uris[0];
                InputStream inputStream = getContentResolver().openInputStream(pdfUri);

                // Save file
                File tempFile = File.createTempFile("upload", ".pdf", getCacheDir());
                FileOutputStream outputStream = new FileOutputStream(tempFile);
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
                inputStream.close();
                outputStream.close();

                // Set up Google Drive
                com.google.api.services.drive.model.File fileMetadata = new com.google.api.services.drive.model.File();
                fileMetadata.setName(getFileNameFromUri(pdfUri));
                fileMetadata.setParents(Collections.singletonList("14sKmbwmQk_55PGdhmNggUNnLgN5jdKie")); // Parent Folder

                FileContent mediaContent = new FileContent("application/pdf", tempFile);
                com.google.api.services.drive.model.File uploadedFile = driveService.files().create(fileMetadata, mediaContent)
                        .setFields("id") // Get only the file ID
                        .execute();

                String fileId = uploadedFile.getId();
                String downloadLink = "https://drive.google.com/uc?id=" + fileId;


                return shortenUrl(downloadLink);

            } catch (Exception e) {
                Log.e("UploadTask", "Error uploading PDF", e);
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                pdfLink.setText(result);  // Set link but user cannot edit
                Toast.makeText(MainActivity.this, "PDF Uploaded Successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Upload Failed", Toast.LENGTH_SHORT).show();
            }
        }


        private String shortenUrl(String longUrl) {
            try {
                URL url = new URL("https://tinyurl.com/api-create.php?url=" + URLEncoder.encode(longUrl, "UTF-8"));
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                InputStream inputStream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                String shortUrl = reader.readLine();
                reader.close();

                return shortUrl; // Return shortened URL
            } catch (Exception e) {
                Log.e("UploadTask", "Error shortening URL", e);
            }
            return longUrl;
        }
    }




    private void connectToArduino() {
        try {
            UsbManager usbManager = (UsbManager) getSystemService(USB_SERVICE);
            List<UsbSerialDriver> drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager);

            if (drivers.isEmpty()) {
                Toast.makeText(this, "No Arduino detected", Toast.LENGTH_SHORT).show();
                return;
            }

            UsbSerialDriver driver = drivers.get(0);
            UsbDeviceConnection connection = usbManager.openDevice(driver.getDevice());
            if (connection == null) {
                Toast.makeText(this, "Unable to open connection", Toast.LENGTH_SHORT).show();
                return;
            }

            usbSerialPort = driver.getPorts().get(0);
            usbSerialPort.open(connection);

            usbSerialPort.setParameters(BAUD_RATE, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);

            Toast.makeText(this, "Connected to Arduino", Toast.LENGTH_SHORT).show();

            new ReadSerialData().execute();

        } catch (Exception e) {
            Log.e("ArduinoConnection", "Error connecting to Arduino", e);
            Toast.makeText(this, "Connection failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void disconnectFromArduino() {
        try {
            if (usbSerialPort != null) {
                usbSerialPort.close();
                usbSerialPort = null;
                Toast.makeText(this, "Disconnected from Arduino", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("ArduinoDisconnection", "Error disconnecting Arduino", e);
        }
    }

    private void sendLinkToArduino() {
        if (usbSerialPort == null) {
            Toast.makeText(this, "No active serial connection. Please connect first.", Toast.LENGTH_SHORT).show();
            return;
        }

        String uploadLink = pdfLink.getText().toString().trim(); // Read from non-editable TextView
        if (uploadLink.isEmpty()) {
            Toast.makeText(this, "No link to send. Please upload a PDF first.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            String message = uploadLink + "\n";
            usbSerialPort.write(message.getBytes(), 1000);
            Toast.makeText(this, "Link sent to Arduino: " + uploadLink, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e("SendToArduino", "Error sending link", e);
            Toast.makeText(this, "Failed to send link", Toast.LENGTH_SHORT).show();
        }
    }


    private class ReadSerialData extends AsyncTask<Void, String, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                byte[] buffer = new byte[64];
                while (usbSerialPort != null) {
                    int len = usbSerialPort.read(buffer, 1000);
                    if (len > 0) {
                        String receivedData = new String(buffer, 0, len);
                        publishProgress(receivedData);
                    }
                }
            } catch (Exception e) {
                Log.e("ReadSerialData", "Error reading serial data", e);
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            serialMonitor.append(values[0] + "\n");
        }
    }
}
